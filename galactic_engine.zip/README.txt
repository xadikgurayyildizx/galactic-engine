Galactic • Dimensional • Engine (iPhone-friendly web demo)
-------------------------------------------------------

Nasıl kullanılır (iPhone Safari):
1. ZIP içinden dosyaları çıkartıp bir klasöre yerleştir.
2. 'index.html' dosyasını Safari ile aç (dosyalar uygulamada locale olarak çalışır).
   - Alternatif: herhangi bir küçük web sunucusunda (örn. GitHub Pages, Netlify) yayınla.
3. Safari'de sayfayı açtıktan sonra 'Paylaş' -> 'Ana Ekrana Ekle' seçeneğiyle
   uygulamayı ana ekrana ekleyebilirsin. Böylece tek dokunuşla açılır.
4. START tuşuna bas, STS/Density/Reverb/ Brightness sliderları ile oynayarak "galaktik" ambiyansı kontrol et.

Not: STS (7.83Hz) gibi düşük frekanslar hoparlörden direkt olarak duyulmayabilir; burada LFO modülasyonu olarak kullanıyoruz.
